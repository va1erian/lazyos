# Notes

* zip, tar, gz, zst, xz and 7z
