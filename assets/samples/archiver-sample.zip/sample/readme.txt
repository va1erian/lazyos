Welcome to the Archiver sample.
Extract me, or drag me to a Files window.
